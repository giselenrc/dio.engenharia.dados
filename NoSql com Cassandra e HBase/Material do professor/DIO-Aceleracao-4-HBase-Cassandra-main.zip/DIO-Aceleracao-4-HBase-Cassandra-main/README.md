# DIO-Aceleracao-4-HBase-Cassandra

Disponibilizar os arquivos descompactados na VM no caminho /home/everis/arquivos/
